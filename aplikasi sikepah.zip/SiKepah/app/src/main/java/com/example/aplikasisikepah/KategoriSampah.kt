package com.example.aplikasisikepah

data class KategoriSampah(val name: String, val imageResId: Int)
