package com.example.aplikasisikepah.screen

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.NavController
import androidx.navigation.NavHostController


@Composable
fun NavigationGraph(navController: NavController) {
    NavHost(navController = navController as NavHostController, startDestination = Routes.HOME_SCREEN) {
        composable(Routes.HOME_SCREEN) {
            HomeScreen(navController = navController)
        }
        composable(Routes.HISTORY_SCREEN) {
            HistoryScreen(navController = navController)
        }
    }
}
