package com.example.aplikasisikepah.screen

object Routes {
    const val KONFIRMASI_SCREEN = "KONFIRMASI_SCREEN"
    const val HOME_SCREEN = "HOME_SCREEN"
    const val HISTORY_SCREEN = "HISTORY_SCREEN"
    const val PICKUP_SCREEN = "PICKUP_SCREEN"
}