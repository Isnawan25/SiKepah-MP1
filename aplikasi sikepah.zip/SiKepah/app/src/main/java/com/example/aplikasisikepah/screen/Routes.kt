package com.example.aplikasisikepah.screen

object Routes {
    const val HOME_SCREEN = "HOME_SCREEN"
    const val HISTORY_SCREEN = "HISTORY_SCREEN"
}