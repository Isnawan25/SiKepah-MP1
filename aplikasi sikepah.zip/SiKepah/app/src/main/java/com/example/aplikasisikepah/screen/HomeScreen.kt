package com.example.aplikasisikepah.screen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.aplikasisikepah.R

@Composable
fun HomeScreen(navController: NavController) {
    Surface {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            BarAtas()
            Spacer(modifier = Modifier.height(16.dp))
            Spacer(modifier = Modifier.weight(1f))
            Spacer(modifier = Modifier.height(30.dp)) // Added space for bottom padding
            BarBawah(navController = navController)
        }
    }
}

@Composable
fun BarAtas() {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .padding(top = 20.dp)
    ) {
        Text(
            text = "Selamat Datang\nDiSiKepah",
            color = Color.Black,
            fontSize = 30.sp,
            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f),
            textAlign = TextAlign.Left
        )
        Image(
            modifier = Modifier.size(65.dp),
            painter = painterResource(id = R.drawable.logo_app),
            contentDescription = "Native Mobile Bits"
        )
    }
}

@Composable
fun BarBawah(navController: NavController) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.LightGray)
            .padding(vertical = 16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                modifier = Modifier
                    .size(50.dp)
                    .clickable {
                        navController.navigate(Routes.HISTORY_SCREEN)
                    },
                painter = painterResource(id = R.drawable.ic_history),
                contentDescription = "Button 1"
            )
            Spacer(modifier = Modifier.width(100.dp))
            Image(
                modifier = Modifier.size(50.dp),
                painter = painterResource(id = R.drawable.ic_home),
                contentDescription = "Button 2"
            )
            Spacer(modifier = Modifier.width(100.dp))
            Image(
                modifier = Modifier.size(50.dp),
                painter = painterResource(id = R.drawable.ic_pickup),
                contentDescription = "Button 3"
            )
        }
    }
}

@Preview
@Composable
fun HomeScreenPreview() {
    HomeScreen(navController = rememberNavController())
}
